package com.example.lib.common;

public class Url {
    private static String ipv4Address = "192.168.1.7";
    public static final String AppFood_Url = "http://"+ ipv4Address +"/server/";

    public static final String postBillDetail = "http://"+ ipv4Address +"/server/thongTinKhachHang.php";
}
