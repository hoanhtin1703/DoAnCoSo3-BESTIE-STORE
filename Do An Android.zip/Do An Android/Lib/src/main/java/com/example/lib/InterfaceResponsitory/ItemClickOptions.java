package com.example.lib.InterfaceResponsitory;

import android.view.View;

public interface ItemClickOptions {
    void onClickOptions(View view, int pos, int value);
}
